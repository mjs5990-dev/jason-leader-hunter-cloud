# Jason Leader Hunter CLOUD v1.0.0

PC를 켜두지 않아도 **고정 공인 IPv4가 있는 클라우드 VPS**에서 계속 실행되는 한국주식 대장/급등준비 탐색기입니다.
키움 REST API로 시장·분봉·수급·계좌를 조회하고, 조건이 맞으면 Telegram으로 휴대폰 알림을 보냅니다. 자동매수는 다중 잠금이 풀린 경우에만 지정가 주문을 전송합니다.

## 핵심 기능

- 거래대금 상위 후보 → 대장점수 → 진입 타점의 계층형 스캔
- 오전 1분봉 / 11시 이후 5분봉
- MA20 + VWAP + Envelope + RSI + WTO + Banker Flow
- 외국인/기관 수급 보조점수
- ETF/ETN/스팩/우선주/인버스/레버리지 1차 제외 필터
- S/A/B 등급 및 `과매도 반전`, `눌림 재진입`, `당일고가 돌파` 패턴
- Telegram 휴대폰 진입신호 알림
- 모바일 웹 대시보드: 스캔 ON/OFF, 자동매수 ON/OFF, 알림 테스트, 신규매수 비상정지
- 자동매수 안전장치: 서버 ARM, 실계좌 최종 잠금, 등급, 주문시간, 동시보유, 일손실, 재진입, 추격매수 차단
- 계좌 실보유 종목 중복매수 방지
- 봇이 당일 매수한 종목만 `자동매매 보유`로 세어 기존 장기보유 종목과 분리
- SQLite 신호/이벤트/상태 로그
- Docker 배포, Asia/Seoul 시간대 고정

> v1.0.0의 시장 감시는 **REST 폴링형(기본 약 30초 주기)**입니다. 완전한 틱 단위 WebSocket 진입엔진은 다음 단계입니다. 폴링 중 한 회의 실제 소요시간은 후보 수와 API 응답속도에 따라 30초보다 길어질 수 있습니다.

## 왜 Google Drive에서 직접 실행하지 않나

Google Drive는 파일 저장소이지 상시 실행 서버가 아닙니다. 실제 실행은 VPS에서 하고, Drive는 소스/버전 백업에 사용합니다.

```
Kiwoom REST API
       ↓
고정 IP VPS (Docker, 24시간)
       ↓
Leader Hunter Engine
  ├─ Telegram → 휴대폰 푸시
  ├─ Mobile Dashboard
  └─ Guarded Auto Buy (선택)
```

## 준비물

1. Ubuntu 계열 VPS 1대: **고정 공인 IPv4 필수**
2. 키움 REST API 서비스 신청 + 모의/실전 App Key, App Secret
3. VPS 공인 IPv4를 키움 REST API 허용 IP에 등록
4. Telegram Bot Token + 본인 Chat ID
5. Docker + Docker Compose

**App Secret, Telegram Bot Token을 채팅이나 Google Drive에 올리지 마세요.** 서버의 `.env` 파일에만 입력합니다.

## 1. 서버에 설치

```bash
unzip Jason_Leader_Hunter_Cloud_v1.0.0.zip
cd Jason_Leader_Hunter_Cloud_v1.0.0
cp .env.example .env
nano .env
```

처음에는 아래처럼 유지합니다.

```env
KIWOOM_ENV=mock
SYNTHETIC_MODE=true
AUTO_BUY_ARMED=false
AUTO_BUY_ENABLED=false
ALLOW_LIVE_ORDERS=false
```

실행:

```bash
docker compose up -d --build
docker compose logs -f hunter
```

## 2. Telegram 연결

Telegram에서 `@BotFather`로 봇을 만든 뒤 Bot Token을 `.env`의 `TELEGRAM_BOT_TOKEN`에 입력합니다.
휴대폰에서 만든 봇에게 아무 메시지나 한 번 보낸 뒤:

```bash
docker compose exec hunter python tools/telegram_chat_id.py
```

표시되는 Chat ID를 `.env`의 `TELEGRAM_CHAT_ID`에 입력하고 재시작합니다.

```bash
docker compose up -d --build
```

모바일 대시보드의 **📱 알림 테스트**를 눌러 Telegram 도착을 확인합니다.

## 3. 키움 모의투자 연결

`.env`에서:

```env
KIWOOM_ENV=mock
KIWOOM_APP_KEY=모의투자_APP_KEY
KIWOOM_SECRET_KEY=모의투자_APP_SECRET
SYNTHETIC_MODE=false
```

VPS의 공인 IPv4가 키움 REST API의 허용 IP로 등록되어 있어야 합니다.

재시작:

```bash
docker compose up -d --build
```

키움 모의투자는 계좌/주문이 KRX만 지원되므로 코드가 모의주문에서는 자동으로 KRX를 사용합니다.

## 4. 자동매수 단계별 잠금

### 단계 A — 알림만

```env
AUTO_BUY_ARMED=false
AUTO_BUY_ENABLED=false
```

추천 시작 상태입니다.

### 단계 B — 모의 자동매수

```env
KIWOOM_ENV=mock
AUTO_BUY_ARMED=true
AUTO_BUY_ENABLED=false
```

서버 재시작 후 휴대폰 대시보드에서 `자동매수 ON/OFF`를 눌러 켭니다.

### 단계 C — 실계좌

실전 App Key/Secret 및 등록 IP를 확인한 뒤에만:

```env
KIWOOM_ENV=prod
AUTO_BUY_ARMED=true
AUTO_BUY_ENABLED=false
ALLOW_LIVE_ORDERS=true
ORDER_EXCHANGE=SOR
```

`ALLOW_LIVE_ORDERS=false`면 실전 환경에서 대시보드 버튼을 눌러도 주문이 차단됩니다.

## 기본 자동매수 리스크 파라미터

```env
PER_ORDER_KRW=100000
MAX_POSITIONS=2
DAILY_LOSS_LIMIT_KRW=100000
REENTRY_COOLDOWN_MIN=30
MAX_SIGNAL_AGE_SEC=30
MIN_AUTO_GRADE=A
AUTO_ORDER_START=09:00
AUTO_ORDER_END=15:20
```

- 계좌에 이미 보유한 종목은 자동 추가매수하지 않습니다.
- `MAX_POSITIONS`는 기존 장기보유 전체가 아니라 **이 봇이 당일 매수해 실제 보유 중인 종목**을 셉니다.
- 일손실 한도는 키움의 당일 실현손익을 이용해 신규매수를 차단합니다.
- 비상정지는 **신규매수만 차단**합니다. 미체결 주문 취소나 보유종목 강제매도는 하지 않습니다.

## 모바일 대시보드

기본 포트는 `8000`입니다.

```text
http://SERVER_IP:8000
```

`DASHBOARD_USER`, `DASHBOARD_PASSWORD`로 Basic Auth를 사용합니다. **공개 인터넷에 HTTP 그대로 노출하지 마세요.** 실제 사용은 HTTPS 리버스 프록시(Caddy/Nginx) 또는 Tailscale/WireGuard 같은 사설망을 권장합니다. Telegram 알림만 사용할 경우 8000 포트를 외부에 공개할 필요가 없습니다.

## 검증

네트워크/주문을 발생시키지 않는 내장 테스트:

```bash
python self_test.py
```

또는 Docker에서:

```bash
docker compose run --rm hunter python self_test.py
```

배포 전 검증 순서는 다음을 권장합니다.

1. `SYNTHETIC_MODE=true`: UI/Telegram만 확인
2. `mock + AUTO_BUY_ARMED=false`: 실제 키움 데이터/신호 확인
3. `mock + AUTO_BUY_ARMED=true`: 모의 자동주문 확인
4. 충분한 장중 로그 후에만 실전 키로 전환

## 현재 v1.0.0의 한계

- 신호 감시는 REST 폴링형이며 아직 틱 WebSocket 기반은 아닙니다.
- 뉴스/공시의 의미분석 악재 필터는 아직 서버판에 미포함입니다.
- 섹터 자금 유입을 별도 업종 API로 계산하는 모듈은 후속 버전에서 강화할 예정입니다.
- 자동매수는 들어 있지만 **자동매도/손절 주문은 v1.0.0에서 의도적으로 비활성**입니다. 현재는 진입 탐지와 매수 안전성 검증을 우선합니다.
- ETF/ETN 제외는 종목명·업종 메타 기반 1차 필터입니다. 실전 전 해당 거래대금 상위 결과에서 필터 정확도를 반드시 점검하십시오.

## 파일 구조

```text
app/config.py      환경/리스크 잠금
app/kiwoom.py      OAuth, 시세, 분봉, 수급, 계좌, 매수주문
app/indicators.py  RSI/WTO/Banker/MA20/VWAP/Envelope
app/engine.py      대장점수/진입패턴/AutoBuyGuard
app/scanner.py     전체 오케스트레이션
app/notifier.py    Telegram
app/main.py        FastAPI 모바일 대시보드
app/store.py       SQLite 로그
tools/telegram_chat_id.py
```
