from __future__ import annotations
import asyncio, tempfile
from datetime import datetime, timedelta
from pathlib import Path

from app.models import StockState
from app.engine import LeaderEngine, AutoBuyGuard
from app.kiwoom import KiwoomREST
from app.store import Store

checks=0

def ok(cond,msg):
    global checks
    checks+=1
    if not cond: raise AssertionError(msg)

# 1) Engine produces a valid guarded signal from a strong leader snapshot.
s=StockState(code='000001',name='TEST',sector='테스트',price=12000,prev_close=11200,open_price=11400,
    day_high=12020,day_low=11300,vwap=11940,change_pct=7.1,turnover_100m=850,execution_strength=138,
    volume_accel=1.8,foreign_net_100m=80,institution_net_100m=45,rsi14=64,wto=75,wto_signal_line=60,
    wto_cross='상단유지',banker_trend=76,banker_line=55,banker_state='강한 유입/확대',env_position='중심선 대비 +1.10%',ma20=11850)
e=LeaderEngine(); st,sig=e.update(s)
ok(sig is not None,'strong leader should signal')
ok(sig.stop < sig.entry_low <= sig.entry_high < sig.target1 < sig.target2,'price level ordering')
ok(sig.grade in {'S','A','B'},'signal grade')

class Cfg:
    min_auto_grade='A'; auto_order_start='00:00'; auto_order_end='23:59'; max_positions=2
    daily_loss_limit_krw=100000; max_signal_age_sec=60; reentry_cooldown_min=30; per_order_krw=100000
    def __init__(self,armed=True): self.armed=armed
    def order_interlock_ok(self,runtime_enabled=True): return self.armed and runtime_enabled

g=AutoBuyGuard(Cfg(True))
d=g.decide(sig,sig.price,0,0,None,True)
ok(d.allowed and d.qty>=1,'guard allows valid setup')
ok(not g.decide(sig,sig.price,2,0,None,True).allowed,'max positions blocks')
ok(not g.decide(sig,sig.price,0,-100001,None,True).allowed,'daily loss blocks')
ok(not AutoBuyGuard(Cfg(False)).decide(sig,sig.price,0,0,None,True).allowed,'server arm blocks')
ok(not g.decide(sig,sig.entry_high*1.02,0,0,None,True).allowed,'chase block')
ok(not g.decide(sig,sig.price,0,0,datetime.now()-timedelta(minutes=5),True).allowed,'reentry cooldown')

# 2) Persistent order recovery.
with tempfile.TemporaryDirectory() as td:
    store=Store(Path(td)/'t.db')
    store.event('BUY_ORDER','005930','test')
    ok('005930' in store.todays_buy_order_codes(),'recover managed order code')

# 3) Account parser de-duplicates KRX/NXT views and parses realized P/L without network.
class ApiCfg:
    kiwoom_env='prod'; api_delay_sec=0
    app_key='x'; secret_key='y'; base_url='https://invalid'

class FakeAPI(KiwoomREST):
    async def post(self,api_id,path,body,cont_yn=None,next_key=None):
        if api_id=='kt00018':
            qty='3' if body['dmst_stex_tp']=='KRX' else '3'
            return {'acnt_evlt_remn_indv_tot':[{'stk_cd':'A005930','stk_nm':'삼성전자','rmnd_qty':qty,'trde_able_qty':qty,'pur_pric':'70000','cur_prc':'71000','evltv_prft':'3000','prft_rt':'1.4'}]}
        if api_id=='ka10074': return {'rlzt_pl':'-12345'}
        raise AssertionError(api_id)

async def api_test():
    a=FakeAPI(ApiCfg())
    try:
        p=await a.account_snapshot(); ok(len(p)==1 and p['005930']['qty']==3,'account de-dup')
        pl=await a.daily_realized_pnl(); ok(pl==-12345,'realized pnl parse')
    finally: await a.close()
asyncio.run(api_test())

print(f'PASS {checks} checks')
