from __future__ import annotations
import hmac, logging, os, secrets
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from .config import settings
from .scanner import Scanner, RuntimeState

logging.basicConfig(level=getattr(logging,settings.log_level,logging.INFO),format='%(asctime)s %(levelname)s %(name)s %(message)s')
security=HTTPBasic()
state=RuntimeState(settings)
scanner=Scanner(settings,state)

def auth(c:HTTPBasicCredentials=Depends(security)):
    u=hmac.compare_digest(c.username.encode(),settings.dashboard_user.encode())
    p=hmac.compare_digest(c.password.encode(),settings.dashboard_password.encode())
    if not(u and p): raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,headers={'WWW-Authenticate':'Basic'})
    return True

@asynccontextmanager
async def life(app:FastAPI):
    await scanner.start()
    yield
    await scanner.close()

app=FastAPI(title='Jason Leader Hunter CLOUD',version='1.0.0',lifespan=life)

@app.get('/health')
def health(): return {'ok':True,'version':'1.0.0','environment':settings.kiwoom_env,'synthetic':settings.synthetic_mode}

@app.get('/api/state')
def api_state(_:bool=Depends(auth)):
    return {'runtime':state.summary(),'candidates':state.candidates[:20],'signals':state.signals[:30],
            'guard':{'armed':settings.auto_buy_armed,'live_orders_allowed':settings.allow_live_orders,'per_order_krw':settings.per_order_krw,'max_positions':settings.max_positions,'daily_loss_limit_krw':settings.daily_loss_limit_krw}}

@app.post('/api/scan/toggle')
def scan_toggle(_:bool=Depends(auth)):
    state.scanning=not state.scanning
    return {'scanning':state.scanning}

@app.post('/api/autobuy/toggle')
def autobuy_toggle(_:bool=Depends(auth)):
    if state.emergency_stop: raise HTTPException(409,'비상정지 상태에서는 자동매수를 켤 수 없습니다')
    if not settings.auto_buy_armed: raise HTTPException(409,'서버의 AUTO_BUY_ARMED가 false입니다')
    if settings.kiwoom_env=='prod' and not settings.allow_live_orders: raise HTTPException(409,'실계좌 주문 잠금(ALLOW_LIVE_ORDERS=false)')
    state.auto_buy=not state.auto_buy
    return {'auto_buy':state.auto_buy}

@app.post('/api/emergency-stop')
def emergency(_:bool=Depends(auth)):
    state.emergency_stop=True; state.auto_buy=False
    return {'emergency_stop':True,'auto_buy':False,'note':'신규 자동매수만 즉시 차단합니다. 기존 주문 취소/보유주식 매도는 자동 실행하지 않습니다.'}

@app.post('/api/emergency-reset')
def emergency_reset(_:bool=Depends(auth)):
    state.emergency_stop=False
    return {'emergency_stop':False,'auto_buy':False}

@app.post('/api/scan/now')
async def scan_now(_:bool=Depends(auth)):
    await scanner.scan_once(); return {'ok':True,'last_scan':state.last_scan.isoformat() if state.last_scan else None}

@app.post('/api/notify/test')
async def notify_test(_:bool=Depends(auth)):
    ok=await scanner.note.text('✅ Jason Leader Hunter CLOUD 알림 테스트 성공')
    if not ok: raise HTTPException(409,'Telegram 설정을 확인하세요')
    return {'ok':True}

HTML=r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jason Leader Hunter</title><style>
:root{color-scheme:dark}body{font-family:system-ui,-apple-system,sans-serif;background:#080d16;color:#eaf1ff;margin:0}.wrap{max-width:980px;margin:auto;padding:14px}.head{display:flex;justify-content:space-between;align-items:center;gap:10px}.logo{font-size:22px;font-weight:900}.muted{color:#8fa2bf;font-size:12px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}.card{background:#101827;border:1px solid #253249;border-radius:14px;padding:12px}.v{font-size:20px;font-weight:850;margin-top:4px}.ok{color:#55e69d}.bad{color:#ff7085}.warn{color:#ffd166}.btns{display:flex;gap:7px;flex-wrap:wrap}.btn{border:0;border-radius:12px;padding:11px 14px;font-weight:800;background:#253958;color:#fff}.red{background:#a72b3f}.green{background:#166843}.table{width:100%;border-collapse:collapse;font-size:13px}.table th,.table td{padding:9px 7px;border-bottom:1px solid #243048;text-align:right}.table th:first-child,.table td:first-child{text-align:left}.gS{color:#ffcc4d;font-weight:900}.gA{color:#ff7c7c;font-weight:900}.gB{color:#61b8ff}.sig{padding:10px 0;border-bottom:1px solid #243048}.sig b{font-size:16px}@media(max-width:700px){.grid{grid-template-columns:1fr 1fr}.hideM{display:none}.table{font-size:11px}.table th,.table td{padding:8px 4px}}
</style></head><body><div class="wrap"><div class="head"><div><div class="logo">JASON LEADER HUNTER ☁️</div><div class="muted">CLOUD · Kiwoom REST · Telegram</div></div><div id="clock" class="muted"></div></div>
<div class="grid"><div class="card"><div class="muted">스캐너</div><div id="scan" class="v">-</div></div><div class="card"><div class="muted">자동매수</div><div id="auto" class="v">-</div></div><div class="card"><div class="muted">환경</div><div id="env" class="v">-</div></div><div class="card"><div class="muted">비상정지</div><div id="estop" class="v">-</div></div><div class="card"><div class="muted">자동매매 보유</div><div id="pos" class="v">-</div></div><div class="card"><div class="muted">오늘 실현손익</div><div id="pnl" class="v">-</div></div></div>
<div class="card"><div class="btns"><button class="btn" onclick="post('/api/scan/toggle')">스캔 ON/OFF</button><button class="btn green" onclick="post('/api/autobuy/toggle')">자동매수 ON/OFF</button><button class="btn" onclick="post('/api/scan/now')">지금 스캔</button><button class="btn" onclick="post('/api/notify/test')">📱 알림 테스트</button><button class="btn red" onclick="post('/api/emergency-stop')">🚨 신규매수 비상정지</button><button class="btn" onclick="post('/api/emergency-reset')">비상정지 해제</button></div><div id="err" class="muted" style="margin-top:8px"></div></div>
<h3>대장 / 급등 준비 후보</h3><div class="card" style="overflow:auto"><table class="table"><thead><tr><th>종목</th><th>등급</th><th>DT</th><th>등락</th><th>거래대금(억)</th><th>체결</th><th>WTO</th><th>Banker</th><th class="hideM">상태</th></tr></thead><tbody id="cand"></tbody></table></div>
<h3>최근 진입신호</h3><div class="card" id="sigs"></div><div class="muted" style="margin:14px 0">※ 실주문은 서버의 AUTO_BUY_ARMED + ALLOW_LIVE_ORDERS 이중 잠금을 모두 풀어야 합니다. 비상정지는 신규매수를 막으며 기존 주문을 자동 취소하지 않습니다.</div></div>
<script>
async function get(){let r=await fetch('/api/state'); if(!r.ok)return; let d=await r.json();let x=d.runtime;scan.textContent=x.scanning?'ON':'OFF';scan.className='v '+(x.scanning?'ok':'bad');auto.textContent=x.auto_buy?'ON':'OFF';auto.className='v '+(x.auto_buy?'warn':'');env.textContent=x.environment.toUpperCase();estop.textContent=x.emergency_stop?'STOP':'정상';pos.textContent=(x.managed_position_count??0)+' / '+d.guard.max_positions;pnl.textContent=(x.daily_realized_pnl_krw??0).toLocaleString()+'원';pnl.className='v '+((x.daily_realized_pnl_krw??0)>=0?'ok':'bad');estop.className='v '+(x.emergency_stop?'bad':'ok');err.textContent=x.last_error||('마지막 스캔: '+(x.last_scan||'-'));
 cand.innerHTML=d.candidates.map(a=>`<tr><td><b>${a.name}</b><br><span class=muted>${a.sector}</span></td><td class=g${a.grade}>${a.grade}</td><td>${(a.score_total??0).toFixed(1)}</td><td>${a.change_pct.toFixed(2)}%</td><td>${a.turnover_100m.toFixed(0)}</td><td>${a.execution_strength.toFixed(0)}</td><td>${a.wto_cross}</td><td>${a.banker_state}</td><td class=hideM>${a.status}</td></tr>`).join('');
 sigs.innerHTML=d.signals.length?d.signals.map(s=>`<div class=sig><b class=g${s.grade}>🔥 ${s.grade} ${s.name}</b> <span class=muted>${s.code} · ${s.sector}</span><br>${s.pattern} · DT ${s.total_score.toFixed(1)}<br><span class=muted>진입 ${s.entry_low.toLocaleString()}~${s.entry_high.toLocaleString()} / 손절 ${s.stop.toLocaleString()} / 1차 ${s.target1.toLocaleString()} / 2차 ${s.target2.toLocaleString()}</span></div>`).join(''):'<span class=muted>아직 신호 없음</span>';}
async function post(u){let r=await fetch(u,{method:'POST'});let t=await r.text();if(!r.ok)alert(t);await get()}; setInterval(()=>{clock.textContent=new Date().toLocaleString('ko-KR');},1000);setInterval(get,5000);get();
</script></body></html>'''

@app.get('/',response_class=HTMLResponse)
def dashboard(_:bool=Depends(auth)): return HTML
