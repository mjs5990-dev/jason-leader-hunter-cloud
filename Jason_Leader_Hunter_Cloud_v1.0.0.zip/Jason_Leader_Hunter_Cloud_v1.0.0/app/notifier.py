from __future__ import annotations
import httpx
from .models import Signal

class TelegramNotifier:
    def __init__(self,settings):
        self.token=settings.telegram_bot_token; self.chat_id=settings.telegram_chat_id
        self.enabled=bool(self.token and self.chat_id)
        self.client=httpx.AsyncClient(timeout=10.0)
    async def close(self): await self.client.aclose()
    async def send(self,text:str):
        if not self.enabled: return False
        url=f"https://api.telegram.org/bot{self.token}/sendMessage"
        r=await self.client.post(url,json={"chat_id":self.chat_id,"text":text,"disable_web_page_preview":True})
        return r.status_code<300
    async def signal(self,s:Signal,auto_note:str=""):
        msg=(f"🔥 {s.grade}급 진입신호\n{s.name} ({s.code}) · {s.sector}\n"
             f"패턴: {s.pattern}\nDT: {s.total_score:.1f}\n현재가: {s.price:,}\n"
             f"진입: {s.entry_low:,} ~ {s.entry_high:,}\n손절: {s.stop:,}\n"
             f"1차: {s.target1:,} / 2차: {s.target2:,}\n{s.rationale}")
        if s.warnings: msg+=f"\n⚠️ {s.warnings}"
        if auto_note: msg+=f"\n🤖 {auto_note}"
        return await self.send(msg)

# Compatibility alias used by the mobile dashboard's notification test.
TelegramNotifier.text = TelegramNotifier.send
