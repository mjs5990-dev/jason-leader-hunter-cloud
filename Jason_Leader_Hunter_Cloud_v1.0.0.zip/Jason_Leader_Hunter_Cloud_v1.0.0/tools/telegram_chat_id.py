import os, asyncio, httpx

async def main():
    token=os.getenv('TELEGRAM_BOT_TOKEN','').strip()
    if not token:
        print('TELEGRAM_BOT_TOKEN이 비어 있습니다. .env에 먼저 입력하세요.'); return
    async with httpx.AsyncClient(timeout=10) as c:
        r=await c.get(f'https://api.telegram.org/bot{token}/getUpdates')
        data=r.json()
    rows=[]
    for x in data.get('result',[]):
        msg=x.get('message') or x.get('channel_post') or {}
        chat=msg.get('chat') or {}
        if chat.get('id') is not None:
            rows.append((chat.get('id'),chat.get('type'),chat.get('title') or chat.get('username') or chat.get('first_name')))
    if not rows:
        print('메시지가 없습니다. 휴대폰 Telegram에서 봇에게 먼저 아무 메시지나 보낸 뒤 다시 실행하세요.')
    else:
        print('가장 최근 CHAT ID:',rows[-1][0]); print('후보:',rows[-10:])
asyncio.run(main())
