from __future__ import annotations
from typing import Optional, Sequence
from .models import Candle


def sma(v: Sequence[float], n: int) -> list[Optional[float]]:
    out: list[Optional[float]] = [None]*len(v)
    if n <= 0: return out
    s = 0.0
    for i,x in enumerate(v):
        s += x
        if i >= n: s -= v[i-n]
        if i >= n-1: out[i] = s/n
    return out

def ema(v: Sequence[Optional[float]], n: int) -> list[Optional[float]]:
    out: list[Optional[float]] = [None]*len(v)
    a = 2/(n+1)
    prev: Optional[float] = None
    for i,x in enumerate(v):
        if x is None: continue
        prev = x if prev is None else a*x + (1-a)*prev
        out[i] = prev
    return out

def rolling_low(v: Sequence[float], n: int) -> list[Optional[float]]:
    return [None if i+1<n else min(v[i-n+1:i+1]) for i in range(len(v))]

def rolling_high(v: Sequence[float], n: int) -> list[Optional[float]]:
    return [None if i+1<n else max(v[i-n+1:i+1]) for i in range(len(v))]

def sma_skip_none(v: Sequence[Optional[float]], n: int) -> list[Optional[float]]:
    out=[]
    for i in range(len(v)):
        w=[x for x in v[max(0,i-n+1):i+1] if x is not None]
        out.append(sum(w)/len(w) if len(w)==n else None)
    return out

def cross(a: Sequence[Optional[float]], b: Sequence[Optional[float]]) -> str:
    if len(a)<2 or len(b)<2 or None in (a[-1],a[-2],b[-1],b[-2]): return "-"
    if a[-2] <= b[-2] and a[-1] > b[-1]: return "골든크로스"
    if a[-2] >= b[-2] and a[-1] < b[-1]: return "데드크로스"
    if a[-1] > b[-1]: return "상단유지"
    return "하단유지"

def rsi_wilder(closes: Sequence[float], n: int=14) -> list[Optional[float]]:
    out=[None]*len(closes)
    if len(closes) <= n: return out
    gains=[]; losses=[]
    for i in range(1,n+1):
        d=closes[i]-closes[i-1]
        gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/n; al=sum(losses)/n
    out[n]=100 if al==0 else 100-(100/(1+ag/al))
    for i in range(n+1,len(closes)):
        d=closes[i]-closes[i-1]
        g=max(d,0); l=max(-d,0)
        ag=(ag*(n-1)+g)/n; al=(al*(n-1)+l)/n
        out[i]=100 if al==0 else 100-(100/(1+ag/al))
    return out

def wto(bars: Sequence[Candle]):
    ap=[(b.high+b.low+b.close)/3 for b in bars]
    esa=ema(ap,10)
    dev=[None if esa[i] is None else abs(ap[i]-esa[i]) for i in range(len(ap))]
    d=ema(dev,10)
    ci=[]
    for i in range(len(ap)):
        if esa[i] is None or d[i] is None or abs(d[i])<1e-12: ci.append(None)
        else: ci.append((ap[i]-esa[i])/(0.015*d[i]))
    tci=ema(ci,21)
    sig=sma_skip_none(tci,4)
    return tci,sig

def banker(bars: Sequence[Candle]):
    h=[b.high for b in bars]; l=[b.low for b in bars]; c=[b.close for b in bars]; o=[b.open for b in bars]
    lo27,hi27=rolling_low(l,27),rolling_high(h,27)
    a=[]
    for i,x in enumerate(c):
        if lo27[i] is None or hi27[i] is None or abs(hi27[i]-lo27[i])<1e-12: a.append(None)
        else: a.append((x-lo27[i])/(hi27[i]-lo27[i])*100)
    w1,w2=ema(a,9),ema(ema(a,9),5)
    trend=[None if w1[i] is None or w2[i] is None else (3*w1[i]-2*w2[i]-50)*1.032+50 for i in range(len(bars))]
    tp=[(2*c[i]+h[i]+l[i]+o[i])/5 for i in range(len(bars))]
    lo34,hi34=rolling_low(l,34),rolling_high(h,34)
    raw=[]
    for i in range(len(bars)):
        if lo34[i] is None or hi34[i] is None or abs(hi34[i]-lo34[i])<1e-12: raw.append(None)
        else: raw.append((tp[i]-lo34[i])/(hi34[i]-lo34[i])*100)
    return trend,ema(raw,13)

def banker_state(trend, line) -> str:
    cr=cross(trend,line)
    if not trend or trend[-1] is None or line[-1] is None: return "미확인"
    spread=trend[-1]-line[-1]
    prev=0 if len(trend)<2 or trend[-2] is None or line[-2] is None else trend[-2]-line[-2]
    slope=0 if len(trend)<2 or trend[-2] is None else trend[-1]-trend[-2]
    if cr=="골든크로스": return "유입전환"
    if cr=="데드크로스": return "약세전환"
    if spread>0 and spread>prev and slope>0: return "강한 유입/확대"
    if spread>0 and spread>=prev: return "유입 확대"
    if spread>0 and spread<prev: return "유입 둔화"
    if spread<=0 and spread<prev: return "유출 확대"
    return "약세 유지"

def analyze_bars(bars: Sequence[Candle]) -> dict:
    if len(bars)<40: return {"ready":False}
    closes=[b.close for b in bars]
    m=sma(closes,20); rs=rsi_wilder(closes,14); wt,ws=wto(bars); bt,bl=banker(bars)
    sess=bars
    pv=sum(((b.high+b.low+b.close)/3)*b.volume for b in sess if b.volume>0)
    vv=sum(b.volume for b in sess if b.volume>0)
    vwap=pv/vv if vv else closes[-1]
    recent=range(max(0,len(bars)-13),len(bars)-1)
    reclaim=False
    if m[-1] and m[-2]:
        touched=any(m[i] is not None and bars[i].low<=m[i] for i in recent)
        reclaim=bool(touched and closes[-2]<=m[-2] and closes[-1]>m[-1])
    env="미확인" if not m[-1] else f"중심선 대비 {(closes[-1]/m[-1]-1)*100:+.2f}%"
    if m[-1] and closes[-1] >= m[-1]*1.06: env="상단 +6% 이상"
    elif m[-1] and closes[-1] <= m[-1]*.94: env="하단 -6% 이하"
    elif m[-1] and closes[-1] <= m[-1]*.96: env="하단 -4% 이하"
    elif m[-1] and closes[-1] <= m[-1]*.98: env="하단 -2% 이하"
    vols=[b.volume for b in bars]
    prev20=vols[-21:-1] if len(vols)>=21 else vols[:-1]
    vacc=vols[-1]/(sum(prev20)/len(prev20)) if prev20 and sum(prev20)>0 else 1.0
    return {"ready":True,"ma20":m[-1],"rsi":rs[-1],"wto":wt[-1],"wto_sig":ws[-1],"wto_cross":cross(wt,ws),
            "banker_trend":bt[-1],"banker_line":bl[-1],"banker_state":banker_state(bt,bl),"vwap":vwap,
            "env":env,"ma20_reclaim":reclaim,"volume_accel":vacc}
