from __future__ import annotations
import sqlite3, json, threading
from pathlib import Path
from datetime import datetime
from .models import Signal, StockState

class Store:
    def __init__(self,path:Path):
        path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.Lock(); self.conn=sqlite3.connect(str(path),check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("CREATE TABLE IF NOT EXISTS signals(ts TEXT, code TEXT, name TEXT, grade TEXT, pattern TEXT, score REAL, price INTEGER, entry_low INTEGER, entry_high INTEGER, stop INTEGER, target1 INTEGER, target2 INTEGER, rationale TEXT, warnings TEXT)")
        self.conn.execute("CREATE TABLE IF NOT EXISTS events(ts TEXT, kind TEXT, code TEXT, detail TEXT)")
        self.conn.execute("CREATE TABLE IF NOT EXISTS state(ts TEXT, code TEXT, payload TEXT)")
        self.conn.commit()
    def signal(self,s:Signal):
        with self.lock:
            self.conn.execute("INSERT INTO signals VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(s.created_at.isoformat(),s.code,s.name,s.grade,s.pattern,s.total_score,s.price,s.entry_low,s.entry_high,s.stop,s.target1,s.target2,s.rationale,s.warnings)); self.conn.commit()
    def event(self,kind:str,code:str,detail:str):
        with self.lock:
            self.conn.execute("INSERT INTO events VALUES(?,?,?,?)",(datetime.now().isoformat(),kind,code,detail));self.conn.commit()
    def snapshot(self,s:StockState):
        with self.lock:
            self.conn.execute("INSERT INTO state VALUES(?,?,?)",(datetime.now().isoformat(),s.code,json.dumps(s.to_dict(),ensure_ascii=False)));self.conn.commit()

    def todays_buy_order_codes(self):
        prefix=datetime.now().strftime('%Y-%m-%d')+'%'
        with self.lock:
            cur=self.conn.execute("SELECT DISTINCT code FROM events WHERE kind='BUY_ORDER' AND ts LIKE ?",(prefix,))
            return {str(r[0]) for r in cur.fetchall() if r and r[0]}

    def recent_signals(self,n:int=50):
        with self.lock:
            cur=self.conn.execute("SELECT ts,code,name,grade,pattern,score,price,entry_low,entry_high,stop,target1,target2,rationale,warnings FROM signals ORDER BY rowid DESC LIMIT ?",(n,))
            cols=[x[0] for x in cur.description];return [dict(zip(cols,row)) for row in cur.fetchall()]
