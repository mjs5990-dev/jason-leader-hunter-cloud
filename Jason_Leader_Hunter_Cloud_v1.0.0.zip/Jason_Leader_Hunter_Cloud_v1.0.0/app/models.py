from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Any

@dataclass
class Candle:
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass
class StockState:
    code: str
    name: str
    sector: str = "미분류"
    price: float = 0.0
    prev_close: float = 0.0
    open_price: float = 0.0
    day_high: float = 0.0
    day_low: float = 0.0
    vwap: float = 0.0
    change_pct: float = 0.0
    turnover_100m: float = 0.0
    execution_strength: float = 100.0
    volume_accel: float = 1.0
    foreign_net_100m: Optional[float] = None
    institution_net_100m: Optional[float] = None
    score_leadership: Optional[float] = None
    score_flow: Optional[float] = None
    score_recovery: Optional[float] = None
    score_total: Optional[float] = None
    grade: str = "N/A"
    status: str = "관찰"
    pattern: str = "-"
    no_trade_reason: str = ""
    rsi14: Optional[float] = None
    wto: Optional[float] = None
    wto_signal_line: Optional[float] = None
    wto_cross: str = "-"
    banker_trend: Optional[float] = None
    banker_line: Optional[float] = None
    banker_state: str = "미분석"
    env_position: str = "미분석"
    ma20: Optional[float] = None
    ma20_reclaim: bool = False
    updated_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["updated_at"] = self.updated_at.isoformat()
        return d

@dataclass
class Signal:
    code: str
    name: str
    sector: str
    pattern: str
    grade: str
    total_score: float
    price: int
    entry_low: int
    entry_high: int
    stop: int
    target1: int
    target2: int
    rationale: str
    warnings: str = ""
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["created_at"] = self.created_at.isoformat()
        return d

@dataclass
class OrderDecision:
    allowed: bool
    reason: str
    qty: int = 0
    limit_price: int = 0
