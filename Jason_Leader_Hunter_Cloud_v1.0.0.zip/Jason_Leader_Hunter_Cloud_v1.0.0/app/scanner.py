from __future__ import annotations
import asyncio, logging, random
from datetime import datetime, timedelta
from typing import Optional
from .models import StockState, Signal, Candle
from .indicators import analyze_bars
from .engine import LeaderEngine, AutoBuyGuard
from .kiwoom import KiwoomREST, KiwoomError
from .notifier import TelegramNotifier
from .store import Store

log=logging.getLogger(__name__)

class RuntimeState:
    def __init__(self,settings):
        self.cfg=settings; self.scanning=True; self.auto_buy=settings.auto_buy_enabled
        self.emergency_stop=False; self.last_scan=None; self.last_error=""; self.candidates=[]; self.signals=[]
        self.orders=[]; self.open_order_codes=set(); self.account_holding_codes=set(); self.account_positions={}; self.daily_pnl_krw=0.0; self.last_exit={}
    def summary(self):
        return {"scanning":self.scanning,"auto_buy":self.auto_buy,"emergency_stop":self.emergency_stop,
                "environment":self.cfg.kiwoom_env,"synthetic":self.cfg.synthetic_mode,"last_scan":self.last_scan.isoformat() if self.last_scan else None,
                "last_error":self.last_error,"candidate_count":len(self.candidates),"signal_count":len(self.signals),
                "managed_position_count":len(self.open_order_codes),"account_holding_count":len(self.account_holding_codes),
                "daily_realized_pnl_krw":self.daily_pnl_krw,"orders":self.orders[-20:]}

class Scanner:
    def __init__(self,settings,state:RuntimeState):
        self.cfg=settings; self.state=state; self.api=KiwoomREST(settings); self.note=TelegramNotifier(settings); self.store=Store(settings.db_path)
        self.engine=LeaderEngine(); self.guard=AutoBuyGuard(settings); self.master_loaded=False; self._task=None
        self._managed_today=self.store.todays_buy_order_codes()

    async def close(self):
        if self._task: self._task.cancel()
        await self.api.close(); await self.note.close()

    async def start(self): self._task=asyncio.create_task(self.loop())

    async def loop(self):
        await asyncio.sleep(1)
        while True:
            try:
                if self.state.scanning and not self.state.emergency_stop: await self.scan_once()
            except asyncio.CancelledError: raise
            except Exception as e:
                self.state.last_error=f"{type(e).__name__}: {e}"; log.exception("scan failed")
            await asyncio.sleep(max(5,self.cfg.scan_interval_sec))

    async def scan_once(self):
        states=[]
        if self.cfg.synthetic_mode: states=self._synthetic_states()
        else:
            if not self.master_loaded:
                await self.api.load_master(); self.master_loaded=True
            # Sync the real account before evaluating new automatic entries. Existing
            # long-term holdings are not counted against the bot's max-position limit,
            # but any already-held symbol is blocked from duplicate auto-buying.
            try:
                positions=await self.api.account_snapshot()
                self.state.account_positions=positions
                self.state.account_holding_codes=set(positions)
                self.state.open_order_codes={c for c in self._managed_today if c in positions}
                self.state.daily_pnl_krw=await self.api.daily_realized_pnl()
            except Exception as e:
                log.warning("account sync skipped: %s",e)
            top=await self.api.top_turnover(self.cfg.candidate_limit)
            try: foreign,inst=await self.api.investor_net_maps()
            except Exception: foreign,inst={},{}
            tick='1' if datetime.now().hour<11 else '5'
            for row in top:
                try:
                    bars=await self.api.minute_bars(row['code'],tick); await asyncio.sleep(self.cfg.api_delay_sec)
                    if len(bars)<40: continue
                    tech=analyze_bars(bars)
                    exe=await self.api.execution(row['code']); await asyncio.sleep(self.cfg.api_delay_sec)
                    p=exe['price'] or row['price'] or bars[-1].close
                    day=[b for b in bars if b.ts.date()==datetime.now().date()] or bars[-80:]
                    prev=row['price']/(1+row['change_pct']/100) if row['change_pct']>-99 and row['price'] else 0
                    meta=self.api.master.get(row['code'],{})
                    s=StockState(code=row['code'],name=row['name'],sector=meta.get('sector','미분류'),price=p,prev_close=prev,
                        open_price=day[0].open,day_high=max(b.high for b in day),day_low=min(b.low for b in day),vwap=tech['vwap'],change_pct=row['change_pct'],
                        turnover_100m=(exe['acc_value'] or row['trade_amount'])/100_000_000,execution_strength=exe['execution_strength'],volume_accel=tech['volume_accel'],
                        foreign_net_100m=foreign.get(row['code']),institution_net_100m=inst.get(row['code']),rsi14=tech['rsi'],wto=tech['wto'],wto_signal_line=tech['wto_sig'],
                        wto_cross=tech['wto_cross'],banker_trend=tech['banker_trend'],banker_line=tech['banker_line'],banker_state=tech['banker_state'],env_position=tech['env'],ma20=tech['ma20'],ma20_reclaim=tech['ma20_reclaim'])
                    states.append(s)
                except KiwoomError as e: log.warning("%s skip: %s",row.get('code'),e)
        ranked=[]
        for s in states:
            us,sig=self.engine.update(s); ranked.append(us); self.store.snapshot(us)
            if sig: await self._on_signal(sig,us)
        ranked.sort(key=lambda x:x.score_total or 0,reverse=True)
        self.state.candidates=[x.to_dict() for x in ranked[:30]]; self.state.last_scan=datetime.now(); self.state.last_error=""

    async def _on_signal(self,sig:Signal,state:StockState):
        self.store.signal(sig); self.state.signals.insert(0,sig.to_dict()); self.state.signals=self.state.signals[:100]
        auto_note="자동매수 OFF"
        # runtime toggle can only disable env permission, never elevate it.
        if self.state.auto_buy and not self.state.emergency_stop:
            if sig.code in self.state.account_holding_codes:
                d=None
                auto_note="자동매수 차단: 계좌에 이미 보유 중인 종목"
            else:
                d=self.guard.decide(sig,state.price,len(self.state.open_order_codes),self.state.daily_pnl_krw,self.state.last_exit.get(sig.code),runtime_enabled=self.state.auto_buy)
            if d is not None and d.allowed:
                try:
                    resp=await self.api.buy_limit(sig.code,d.qty,d.limit_price)
                    auto_note=f"지정가 매수 주문 전송 {d.limit_price:,}원 × {d.qty}주 · 주문번호 {resp.get('ord_no','-')}"
                    self._managed_today.add(sig.code); self.state.open_order_codes.add(sig.code); self.state.orders.append({"ts":datetime.now().isoformat(),"code":sig.code,"qty":d.qty,"price":d.limit_price,"ord_no":resp.get('ord_no'),"env":self.cfg.kiwoom_env})
                    self.store.event('BUY_ORDER',sig.code,auto_note)
                except Exception as e:
                    auto_note=f"자동매수 실패: {e}"; self.store.event('BUY_ERROR',sig.code,auto_note)
            elif d is not None: auto_note=f"자동매수 차단: {d.reason}"
        await self.note.signal(sig,auto_note)

    def _synthetic_states(self):
        # Deterministic self-test feed: one strong leader + ordinary candidates.
        base=12000.0
        arr=[]
        for i in range(8):
            strong=(i==0)
            arr.append(StockState(code=f"T{i:05d}",name=("테스트대장" if strong else f"테스트{i}"),sector=("테스트섹터" if i<3 else "기타"),
                price=base+i*130,prev_close=base*.96,open_price=base*.98,day_high=(base+i*130)*(1.003 if strong else 1.02),day_low=base*.96,
                vwap=(base+i*130)*.997,change_pct=7.1 if strong else 2+i*.2,turnover_100m=850 if strong else 100+i*30,
                execution_strength=138 if strong else 100+i,volume_accel=1.8 if strong else 1.0,foreign_net_100m=80 if strong else None,institution_net_100m=45 if strong else None,
                rsi14=64 if strong else 52,wto=75 if strong else 10,wto_signal_line=60 if strong else 12,wto_cross="상단유지" if strong else "하단유지",
                banker_trend=76 if strong else 40,banker_line=55 if strong else 45,banker_state="강한 유입/확대" if strong else "약세 유지",env_position="중심선 대비 +1.10%",ma20=(base+i*130)*.99,ma20_reclaim=False))
        return arr
