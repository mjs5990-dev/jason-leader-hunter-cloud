from __future__ import annotations
import asyncio
from datetime import datetime, timedelta
from typing import Any, Optional
import httpx
from .models import Candle


def num(v: Any, default: float=0.0) -> float:
    if v is None: return default
    try:
        s=str(v).strip().replace(',','').replace('+','')
        return float(s or 0)
    except Exception: return default

def code6(v: Any) -> str:
    s=str(v or '').strip()
    if len(s)==7 and s.startswith('A') and s[1:].isdigit(): s=s[1:]
    for suf in ('_AL','_NX'):
        if s.endswith(suf): s=s[:-3]
    return s

class KiwoomError(RuntimeError): pass

class KiwoomREST:
    def __init__(self, settings):
        self.cfg=settings
        self.client=httpx.AsyncClient(timeout=12.0,headers={"Content-Type":"application/json;charset=UTF-8"})
        self.token: Optional[str]=None
        self.token_expire=datetime.min
        self.master: dict[str,dict[str,Any]]={}
        self._lock=asyncio.Lock()

    async def close(self): await self.client.aclose()

    async def auth(self, force: bool=False) -> str:
        if self.token and not force and datetime.now()<self.token_expire-timedelta(minutes=5): return self.token
        if not self.cfg.app_key or not self.cfg.secret_key: raise KiwoomError("KIWOOM_APP_KEY / KIWOOM_SECRET_KEY가 비어 있습니다")
        async with self._lock:
            if self.token and not force and datetime.now()<self.token_expire-timedelta(minutes=5): return self.token
            r=await self.client.post(self.cfg.base_url+"/oauth2/token",json={"grant_type":"client_credentials","appkey":self.cfg.app_key,"secretkey":self.cfg.secret_key})
            if r.status_code>=400: raise KiwoomError(f"토큰 HTTP {r.status_code}: {r.text[:300]}")
            data=r.json(); tok=data.get('token') or data.get('access_token')
            if not tok: raise KiwoomError(f"토큰 응답 이상: {data}")
            self.token=tok
            exp=data.get('expires_dt')
            try: self.token_expire=datetime.strptime(str(exp),'%Y%m%d%H%M%S') if exp else datetime.now()+timedelta(hours=23)
            except Exception: self.token_expire=datetime.now()+timedelta(hours=23)
            return tok

    async def post(self,api_id:str,path:str,body:dict[str,Any],cont_yn:Optional[str]=None,next_key:Optional[str]=None)->dict[str,Any]:
        tok=await self.auth()
        h={"authorization":f"Bearer {tok}","api-id":api_id}
        if cont_yn: h['cont-yn']=cont_yn
        if next_key: h['next-key']=next_key
        r=await self.client.post(self.cfg.base_url+path,headers=h,json=body)
        if r.status_code==401:
            tok=await self.auth(True); h['authorization']=f"Bearer {tok}"; r=await self.client.post(self.cfg.base_url+path,headers=h,json=body)
        if r.status_code>=400: raise KiwoomError(f"{api_id} HTTP {r.status_code}: {r.text[:400]}")
        data=r.json()
        if data.get('return_code') not in (None,0,'0'): raise KiwoomError(f"{api_id}: {data.get('return_msg',data)}")
        data['_cont_yn']=r.headers.get('cont-yn',''); data['_next_key']=r.headers.get('next-key','')
        return data

    async def load_master(self):
        out={}
        for market in ('0','10'):
            data=await self.post('ka10099','/api/dostk/stkinfo',{'mrkt_tp':market})
            for x in data.get('list',[]) or []:
                if not isinstance(x,dict): continue
                c=code6(x.get('code'))
                if not c: continue
                name=str(x.get('name') or '')
                sector=str(x.get('upName') or '미분류')
                u=name.upper(); su=sector.upper()
                fund_prefixes=('KODEX','TIGER','RISE','ACE','SOL ','PLUS ','HANARO','KOSEF','TIMEFOLIO','ARIRANG','KBSTAR','WON ','1Q ')
                excluded=('ETF' in u or 'ETN' in u or 'ETF' in su or 'ETN' in su or
                          '인버스' in name or '레버리지' in name or '스팩' in name or
                          name.endswith(('우','우B','우C')) or u.startswith(fund_prefixes))
                if excluded: continue
                out[c]={"name":name,"sector":sector,"nxt":str(x.get('nxtEnable') or '')}
            await asyncio.sleep(self.cfg.api_delay_sec)
        self.master=out
        return out

    async def top_turnover(self,limit:int=30)->list[dict[str,Any]]:
        body={"mrkt_tp":"000","sort_tp":"3","mang_stk_incls":"4","crd_tp":"0","trde_qty_tp":"0","pric_tp":"2","trde_prica_tp":"100","mrkt_open_tp":"1","stex_tp":"3"}
        data=await self.post('ka10030','/api/dostk/rkinfo',body)
        rows=data.get('tdy_trde_qty_upper',[]) or []
        result=[]
        for x in rows:
            if not isinstance(x,dict): continue
            c=code6(x.get('stk_cd')); name=str(x.get('stk_nm') or self.master.get(c,{}).get('name',''))
            if self.master and c not in self.master: continue
            if '스팩' in name or name.endswith(('우','우B','우C')): continue
            result.append({"code":c,"name":name,"price":abs(num(x.get('cur_prc'))),"change_pct":num(x.get('flu_rt')),"trade_amount":abs(num(x.get('trde_prica') if x.get('trde_prica') is not None else x.get('trde_amt'))),"volume":abs(num(x.get('trde_qty')))})
            if len(result)>=limit: break
        return result

    async def execution(self,code:str)->dict[str,Any]:
        data=await self.post('ka10003','/api/dostk/stkinfo',{'stk_cd':f'{code}_AL' if self.cfg.kiwoom_env=='prod' else code})
        rows=data.get('cntr_infr',[]) or []
        x=rows[0] if rows and isinstance(rows[0],dict) else {}
        return {"price":abs(num(x.get('cur_prc'))),"acc_volume":abs(num(x.get('acc_trde_qty'))),"acc_value":abs(num(x.get('acc_trde_prica'))),"execution_strength":num(x.get('cntr_str'),100)}

    async def minute_bars(self,code:str,tick_scope:str)->list[Candle]:
        symbol=f'{code}_AL' if self.cfg.kiwoom_env=='prod' else code
        data=await self.post('ka10080','/api/dostk/chart',{'stk_cd':symbol,'tic_scope':tick_scope,'upd_stkpc_tp':'1','base_dt':datetime.now().strftime('%Y%m%d')})
        rows=data.get('stk_min_pole_chart_qry',[]) or []
        bars=[]
        for x in rows:
            if not isinstance(x,dict): continue
            ts=str(x.get('cntr_tm') or '')
            try:
                # Usually YYYYMMDDHHMMSS; accept HHMMSS as well.
                dt=datetime.strptime(ts,'%Y%m%d%H%M%S') if len(ts)>=14 else datetime.combine(datetime.now().date(),datetime.strptime(ts[-6:],'%H%M%S').time())
            except Exception: continue
            bars.append(Candle(dt,abs(num(x.get('open_pric'))),abs(num(x.get('high_pric'))),abs(num(x.get('low_pric'))),abs(num(x.get('cur_prc'))),abs(num(x.get('trde_qty')))))
        bars.sort(key=lambda b:b.ts)
        return bars[-180:]

    async def buy_limit(self,code:str,qty:int,price:int)->dict[str,Any]:
        exch='KRX' if self.cfg.kiwoom_env=='mock' else self.cfg.order_exchange
        body={"dmst_stex_tp":exch,"stk_cd":code,"ord_qty":str(qty),"ord_uv":str(price),"trde_tp":"0","cond_uv":""}
        return await self.post('kt10000','/api/dostk/ordr',body)

    async def account_snapshot(self)->dict[str,dict[str,Any]]:
        """Return current domestic-stock holdings keyed by six-digit code.

        The production REST API can expose KRX/NXT account views. A security may
        appear in more than one view, so rows are de-duplicated by code rather
        than summed. Mock investment account/order data is KRX-only.
        """
        positions: dict[str,dict[str,Any]]={}
        exchanges=('KRX',) if self.cfg.kiwoom_env=='mock' else ('KRX','NXT')
        for exch in exchanges:
            try:
                data=await self.post('kt00018','/api/dostk/acnt',{'qry_tp':'1','dmst_stex_tp':exch})
            except KiwoomError:
                if exch=='NXT':
                    continue
                raise
            rows=data.get('acnt_evlt_remn_indv_tot',[]) or []
            for x in rows:
                if not isinstance(x,dict): continue
                c=code6(x.get('stk_cd'))
                qty=int(abs(num(x.get('rmnd_qty'))))
                if not c or qty<=0: continue
                rec={
                    'code':c,
                    'name':str(x.get('stk_nm') or self.master.get(c,{}).get('name','')),
                    'qty':qty,
                    'tradable_qty':int(abs(num(x.get('trde_able_qty')))),
                    'avg_price':abs(num(x.get('pur_pric'))),
                    'current_price':abs(num(x.get('cur_prc'))),
                    'profit_krw':num(x.get('evltv_prft')),
                    'profit_pct':num(x.get('prft_rt')),
                    'exchange':exch,
                }
                old=positions.get(c)
                # Do not double-count the same holding if both exchange views return it.
                if old is None or rec['qty']>old['qty']:
                    positions[c]=rec
            await asyncio.sleep(self.cfg.api_delay_sec)
        return positions

    async def daily_realized_pnl(self,day:Optional[datetime]=None)->float:
        d=(day or datetime.now()).strftime('%Y%m%d')
        data=await self.post('ka10074','/api/dostk/acnt',{'strt_dt':d,'end_dt':d})
        # Current API returns the summary at top level; keep a defensive fallback.
        if 'rlzt_pl' in data:
            return num(data.get('rlzt_pl'))
        rows=data.get('dt_rlzt_pl',[]) or []
        return sum(num(x.get('tdy_sel_pl')) for x in rows if isinstance(x,dict))

    async def investor_net_maps(self)->tuple[dict[str,float],dict[str,float]]:
        foreign: dict[str,float]={}; inst: dict[str,float]={}
        for org,target in (("9000",foreign),("9999",inst)):
            data=await self.post('ka10065','/api/dostk/rkinfo',{'trde_tp':'1','mrkt_tp':'000','orgn_tp':org,'amt_qty_tp':'1'})
            for x in data.get('opmr_invsr_trde_upper',[]) or []:
                if isinstance(x,dict): target[code6(x.get('stk_cd'))]=num(x.get('netslmt'))
            await asyncio.sleep(self.cfg.api_delay_sec)
        return foreign,inst
