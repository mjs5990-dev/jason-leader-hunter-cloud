from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path


def _b(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1","true","yes","on"}

def _i(name: str, default: int) -> int:
    try: return int(os.getenv(name, str(default)))
    except Exception: return default

def _f(name: str, default: float) -> float:
    try: return float(os.getenv(name, str(default)))
    except Exception: return default

@dataclass(frozen=True)
class Settings:
    kiwoom_env: str = os.getenv("KIWOOM_ENV", "mock").strip().lower()
    app_key: str = os.getenv("KIWOOM_APP_KEY", "").strip()
    secret_key: str = os.getenv("KIWOOM_SECRET_KEY", "").strip()
    scan_interval_sec: int = _i("SCAN_INTERVAL_SEC", 30)
    candidate_limit: int = _i("CANDIDATE_LIMIT", 24)
    api_delay_sec: float = _f("API_DELAY_SEC", 0.22)
    synthetic_mode: bool = _b("SYNTHETIC_MODE", False)

    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "").strip()

    dashboard_user: str = os.getenv("DASHBOARD_USER", "jason").strip()
    dashboard_password: str = os.getenv("DASHBOARD_PASSWORD", "change-me-now").strip()

    auto_buy_enabled: bool = _b("AUTO_BUY_ENABLED", False)
    auto_buy_armed: bool = _b("AUTO_BUY_ARMED", False)
    allow_live_orders: bool = _b("ALLOW_LIVE_ORDERS", False)
    order_exchange: str = os.getenv("ORDER_EXCHANGE", "SOR").strip().upper()
    per_order_krw: int = _i("PER_ORDER_KRW", 100_000)
    max_positions: int = _i("MAX_POSITIONS", 2)
    daily_loss_limit_krw: int = _i("DAILY_LOSS_LIMIT_KRW", 100_000)
    reentry_cooldown_min: int = _i("REENTRY_COOLDOWN_MIN", 30)
    max_signal_age_sec: int = _i("MAX_SIGNAL_AGE_SEC", 30)
    min_auto_grade: str = os.getenv("MIN_AUTO_GRADE", "A").strip().upper()
    auto_order_start: str = os.getenv("AUTO_ORDER_START", "09:00")
    auto_order_end: str = os.getenv("AUTO_ORDER_END", "15:20")

    db_path: Path = Path(os.getenv("DB_PATH", "/app/data/hunter.db"))
    log_level: str = os.getenv("LOG_LEVEL", "INFO").upper()

    @property
    def base_url(self) -> str:
        return "https://mockapi.kiwoom.com" if self.kiwoom_env == "mock" else "https://api.kiwoom.com"

    @property
    def ws_url(self) -> str:
        host="mockapi.kiwoom.com" if self.kiwoom_env=="mock" else "api.kiwoom.com"
        return f"wss://{host}:10000/api/dostk/websocket"

    def order_interlock_ok(self, runtime_enabled: bool = True) -> bool:
        if not self.auto_buy_armed or not runtime_enabled:
            return False
        if self.kiwoom_env == "prod" and not self.allow_live_orders:
            return False
        return True

settings = Settings()
