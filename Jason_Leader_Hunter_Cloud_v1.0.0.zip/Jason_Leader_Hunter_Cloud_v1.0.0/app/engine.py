from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import replace
from datetime import datetime, timedelta, time
from typing import Optional
from .models import StockState, Signal, OrderDecision


def clamp(x: float, lo: float=0.0, hi: float=100.0) -> float:
    return max(lo,min(hi,x))

def tick_size(price: float) -> int:
    # Practical KRX cash-equity tick bands. This is used for price hygiene only.
    if price < 2_000: return 1
    if price < 5_000: return 5
    if price < 20_000: return 10
    if price < 50_000: return 50
    if price < 200_000: return 100
    if price < 500_000: return 500
    return 1_000

def round_tick(p: float) -> int:
    t=tick_size(max(p,1)); return int(round(p/t)*t)

def floor_tick(p: float) -> int:
    t=tick_size(max(p,1)); return int(p//t*t)

class LeaderEngine:
    BANKER_POS={"유입전환","강한 유입/확대","유입 확대","유입 둔화"}
    def __init__(self):
        self.history=defaultdict(lambda: deque(maxlen=32))
        self.last_signal: dict[str,tuple[str,datetime]]={}

    @staticmethod
    def leadership_score(s: StockState)->float:
        turnover=clamp(s.turnover_100m/500*100)
        momentum=clamp((s.change_pct+2)/12*100)
        execution=clamp((s.execution_strength-80)/80*100)
        volume=clamp((s.volume_accel-.7)/2.0*100)
        highpos=50.0
        if s.day_high>s.day_low>0: highpos=clamp((s.price-s.day_low)/(s.day_high-s.day_low)*100)
        vwap=75 if s.vwap>0 and s.price>=s.vwap else 30
        return round(turnover*.24+momentum*.16+execution*.20+volume*.16+highpos*.12+vwap*.12,1)

    @staticmethod
    def flow_score(s: StockState)->Optional[float]:
        vals=[]
        for v in (s.foreign_net_100m,s.institution_net_100m):
            if v is not None: vals.append(clamp(50+v/100*25))
        return None if not vals else round(sum(vals)/len(vals),1)

    @staticmethod
    def wto_points(s: StockState)->float:
        if s.wto is None: return 0
        if s.wto_cross=="골든크로스": return 100
        if s.wto_cross=="상단유지": return clamp(72+(s.wto/100)*12,55,92)
        if s.wto < -45: return 45
        if s.wto_cross=="데드크로스": return 18
        return 38

    @staticmethod
    def banker_points(s: StockState)->float:
        mp={"유입전환":100,"강한 유입/확대":95,"유입 확대":84,"유입 둔화":62,
            "약세 유지":38,"약세전환":20,"유출 확대":10,"미분석":0,"미확인":0}
        return float(mp.get(s.banker_state,40))

    @staticmethod
    def price_structure(s: StockState)->float:
        pts=50.0
        if s.vwap>0: pts += 22 if s.price>=s.vwap else -18
        if s.day_high>s.day_low>0: pts += (((s.price-s.day_low)/(s.day_high-s.day_low))-.5)*35
        if s.execution_strength>=120: pts+=10
        if s.volume_accel>=1.25: pts+=10
        return clamp(pts)

    def total_score(self,s:StockState,lead:float,flow:Optional[float],recovery:float)->float:
        flowv=50 if flow is None else flow
        return round(self.wto_points(s)*.30+self.banker_points(s)*.25+lead*.22+recovery*.18+flowv*.05,1)

    @staticmethod
    def no_trade(s:StockState)->str:
        if s.price<=0: return "가격 데이터 없음"
        if s.wto is None or s.banker_trend is None: return "WTO/Banker 분석 대기"
        if s.vwap>0 and s.price<s.vwap*.975: return "VWAP 과도 이탈"
        if s.day_high>0 and s.price<s.day_high*.90 and s.change_pct>5: return "고점 대비 낙폭 과대"
        return ""

    @staticmethod
    def grade(total:float,no_trade:str)->str:
        if no_trade:return "NO TRADE"
        if total>=88:return "S"
        if total>=80:return "A"
        if total>=70:return "B"
        if total>=60:return "C"
        return "WATCH"

    @staticmethod
    def build_levels(s:StockState,pattern:str):
        t=tick_size(max(s.price,1))
        eh=round_tick(s.price*1.002)
        ref=s.vwap if s.vwap>0 else s.price*.997
        el=round_tick(min(max(ref,s.price*.995),s.price*1.001)); el=min(el,eh)
        if "눌림" in pattern and s.ma20: base=min(s.ma20*.995,el*.988)
        else: base=min((s.vwap*.991 if s.vwap>0 else s.price*.985),el*.986)
        stop=floor_tick(min(base,el-2*t)); stop=max(t,min(stop,eh-2*t))
        risk=max(eh-stop,3*t)
        t1=max(round_tick(eh+risk*1.15),eh+t); t2=max(round_tick(eh+risk*1.8),t1+t)
        return el,eh,stop,t1,t2

    def update(self,s:StockState)->tuple[StockState,Optional[Signal]]:
        self.history[s.code].append(s)
        lead=self.leadership_score(s); flow=self.flow_score(s); rec=self.price_structure(s)
        total=self.total_score(s,lead,flow,rec); nt=self.no_trade(s); gr=self.grade(total,nt)
        h=list(self.history[s.code]); pattern="-"; sig=None
        near_high=s.day_high>0 and s.price>=s.day_high*.994
        vwap_ok=s.vwap<=0 or s.price>=s.vwap*.998
        wto_gc=s.wto_cross=="골든크로스"; wto_hold=s.wto_cross in {"골든크로스","상단유지"}
        banker_ok=s.banker_state in self.BANKER_POS
        oversold=("하단" in (s.env_position or "")) or (s.wto is not None and s.wto<-45)
        if not nt:
            if oversold and wto_gc and banker_ok and s.execution_strength>=100:
                pattern="과매도 반전 · WTO GC"
            elif wto_gc and banker_ok and vwap_ok and (s.ma20_reclaim or len(h)>=6) and s.execution_strength>=108:
                recent=[x.price for x in h[-8:] if x.price>0]
                if s.ma20_reclaim or (recent and min(recent)<=max(s.vwap,1)*1.008): pattern="눌림 재진입 · WTO GC"
            elif near_high and wto_hold and banker_ok and s.execution_strength>=125 and s.volume_accel>=1.30:
                pattern="당일고가 돌파 · WTO/Banker"
            if pattern!="-" and total>=68:
                last_p,last_t=self.last_signal.get(s.code,("",datetime.min))
                if pattern!=last_p or datetime.now()-last_t>timedelta(minutes=7):
                    el,eh,stop,t1,t2=self.build_levels(s,pattern)
                    warn=[]
                    if s.day_high and s.price>s.day_high*.999: warn.append("고점 직선추격 금지")
                    if flow is None: warn.append("외국인·기관 수급 미확인")
                    tf="1분" if datetime.now().time()<time(11,0) else "5분"
                    sig=Signal(s.code,s.name,s.sector,pattern,gr,total,round_tick(s.price),el,eh,stop,t1,t2,
                               f"{tf} WTO {s.wto_cross} · Banker {s.banker_state} · 거래량 {s.volume_accel:.2f}배 · DT {total:.0f}"," / ".join(warn))
                    self.last_signal[s.code]=(pattern,datetime.now())
        st="타점 발견" if sig else ("진입감시" if total>=70 else "관찰")
        return replace(s,score_leadership=lead,score_flow=flow,score_recovery=rec,score_total=total,grade=gr,status=st,pattern=pattern,no_trade_reason=nt,updated_at=datetime.now()),sig

class AutoBuyGuard:
    RANK={"S":4,"A":3,"B":2,"C":1,"WATCH":0}
    def __init__(self,settings): self.cfg=settings
    def decide(self, signal:Signal, current_price:float, open_positions:int, daily_pnl_krw:float, last_exit_at:Optional[datetime]=None, runtime_enabled:bool=True)->OrderDecision:
        if not self.cfg.order_interlock_ok(runtime_enabled): return OrderDecision(False,"자동매수 OFF 또는 실주문 잠금")
        minrank=self.RANK.get(self.cfg.min_auto_grade,3)
        if self.RANK.get(signal.grade,0)<minrank: return OrderDecision(False,f"등급 미달({signal.grade})")
        now=datetime.now()
        sh,sm=map(int,self.cfg.auto_order_start.split(':')); eh,em=map(int,self.cfg.auto_order_end.split(':'))
        if not (time(sh,sm)<=now.time()<=time(eh,em)): return OrderDecision(False,"자동주문 허용시간 밖")
        if open_positions>=self.cfg.max_positions: return OrderDecision(False,"동시보유 상한")
        if daily_pnl_krw<=-abs(self.cfg.daily_loss_limit_krw): return OrderDecision(False,"일손실 한도 도달")
        age=(now-signal.created_at).total_seconds()
        if age>self.cfg.max_signal_age_sec: return OrderDecision(False,"신호 노후화")
        if current_price>signal.entry_high: return OrderDecision(False,"추격매수 차단")
        if current_price<signal.entry_low*.985: return OrderDecision(False,"진입구간 하향 이탈")
        if last_exit_at and now-last_exit_at<timedelta(minutes=self.cfg.reentry_cooldown_min): return OrderDecision(False,"재진입 쿨다운")
        lp=min(signal.entry_high,round_tick(current_price)); qty=max(0,int(self.cfg.per_order_krw//max(lp,1)))
        if qty<1:return OrderDecision(False,"주문금액 부족")
        return OrderDecision(True,"안전조건 통과",qty,lp)
